{
    "name": "Father Luco",
    "version": "16.0.1.0.0",
    "author": "Luis Miguel Gonzalez",
    "maintainer": "Luis Miguel Gonzalez",
    "website": "http://www.luiscodify.com",
    "license": "AGPL-3",
    "category": "Extra Tools",
    "summary": "Father.",
    "depends": ["base"],
    "data": [
        "views/views.xml",
    ],
    # "images": ["static/description/banner.jpg"],
}
